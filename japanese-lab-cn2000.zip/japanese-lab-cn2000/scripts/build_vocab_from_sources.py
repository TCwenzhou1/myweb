import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ZH = ROOT / 'tmp' / 'final.json'
SOURCE_N1 = ROOT / 'tmp' / 'n1.csv'
SOURCE_N2 = ROOT / 'tmp' / 'n2.csv'

def norm(s: str) -> str:
    s = (s or '').strip()
    s = s.replace('〜', '').replace('～', '').replace('~', '')
    s = re.sub(r'\([^)]*\)', '', s)
    s = re.sub(r'（[^）]*）', '', s)
    s = s.replace('　', ' ').strip()
    s = re.sub(r'\s+', '', s)
    return s

def clean_reading(s: str) -> str:
    s = (s or '').strip()
    s = s.replace('〜', '').replace('～', '').replace('~', '')
    s = re.sub(r'\([^)]*\)', '', s)
    s = re.sub(r'（[^）]*）', '', s)
    s = s.replace('　', ' ').strip()
    s = re.sub(r'\s+', '', s)
    return s

def extract_meaning_zh(raw: str) -> str:
    if not raw:
        return ''
    s = raw.strip()
    s = re.sub(r'^[（(][^）)]*[）)]', '', s)
    s = re.sub(r'^[⓪①②③④⑤⑥⑦⑧⑨]+', '', s)
    s = re.sub(r'^【[^】]*】', '', s)
    s = re.sub(r'^\([^)]*\)', '', s)
    s = re.sub(r'^[A-Za-z0-9· ]+', '', s)
    s = s.strip('：: \t')
    if len(s) > 120:
        s = re.split(r'[。；;]', s)[0].strip()
    return s or raw

def is_clean_word(expr: str) -> bool:
    s = expr.strip()
    if '〜' in s or '～' in s or '~' in s:
        return False
    if s.startswith('(') or s.endswith(')') or '（' in s or '）' in s:
        return False
    if ',' in s or ';' in s or '/' in s:
        return False
    if len(norm(s)) == 0:
        return False
    if re.search(r'[A-Za-z]', s):
        return False
    if s.startswith('・') or s.startswith('-'):
        return False
    return True

def main():
    zh_dict = json.loads(SOURCE_ZH.read_text(encoding='utf-8'))
    zh_norm = {}
    for key, value in zh_dict.items():
        nk = norm(key)
        if nk and nk not in zh_norm:
            zh_norm[nk] = value

    rows = []
    for level, path in [('N2', SOURCE_N2), ('N1', SOURCE_N1)]:
        with path.open(encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                expr = row['expression'].strip()
                reading = clean_reading(row['reading'])
                rows.append({
                    'level': level,
                    'expression': expr,
                    'reading': reading,
                    'meaningEn': row['meaning'].strip(),
                    'norm': norm(expr),
                    'zhRaw': zh_norm.get(norm(expr))
                })

    clean = [r for r in rows if is_clean_word(r['expression']) and r['zhRaw']]
    seen = set()
    final = []
    for index, row in enumerate(clean, start=1):
        key = (row['norm'], row['reading'])
        if key in seen:
            continue
        seen.add(key)
        final.append({
            'id': f'v-{index:04d}',
            'word': row['expression'],
            'kana': row['reading'] or row['expression'],
            'level': row['level'],
            'meaningZh': extract_meaning_zh(row['zhRaw']),
            'meaningEn': row['meaningEn'],
            'detailZh': row['zhRaw'],
            'source': 'open-anki-jlpt-decks + Japanese-Chinese-thesaurus',
            'track': 'full'
        })

    core_count = 0
    for item in final:
        if item['level'] == 'N2' and core_count < 2000:
            item['track'] = 'core2000'
            core_count += 1
    for item in final:
        if core_count >= 2000:
            break
        if item['level'] == 'N1' and item['track'] != 'core2000':
            item['track'] = 'core2000'
            core_count += 1

    out_path = ROOT / 'lib' / 'generatedVocab.ts'
    out_path.write_text(
        "export const vocabEntries = " + json.dumps(final, ensure_ascii=False, indent=2) + ";\n",
        encoding='utf-8'
    )
    print(f'Wrote {{len(final)}} entries to {{out_path}}')

if __name__ == '__main__':
    main()
