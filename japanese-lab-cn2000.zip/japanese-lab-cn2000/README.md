# Japanese Lab 中文强化版

这次修复的重点只有两个：

1. **默认展示中文释义**
2. **把“考研核心词太少”提升为可用的 Core 2000 学习层**

## 这版实际包含什么

- 总词条：**3363**
- Core 2000：**2000**
- N2 中文词条：**1325**
- N1 中文词条：**2038**
- TTS 发音：浏览器 `speechSynthesis`
- 收藏本：`localStorage`
- 复习算法：简化版 SM-2 间隔复习

## 文件

- `app/lab/page.tsx` 页面
- `components/WordCard.tsx` 词卡
- `components/ReviewCard.tsx` 复习卡
- `lib/generatedVocab.ts` 生成后的中文词库
- `lib/useSpeech.ts` 发音
- `lib/useStudyStore.ts` 收藏与复习
- `scripts/build_vocab_from_sources.py` 词库构建脚本

## 数据来源

这个版本采用“开源词表 + 开源中日词库映射”的方式生成：

- `open-anki-jlpt-decks`（MIT）
- `Japanese-Chinese-thesaurus`（Unlicense）

## 重要说明

- **Core 2000 不是官方公布的“前 2000 排名”**，而是基于 N2/N1 可用中文词条构建的学习层，适合做第一阶段高频记忆。
- **它不是完整考研 203 词汇表**。考研 203 的要求仍然是约 7000 词及相关词组，这版是为了先把学习体验和中文可用性做正确。
- 浏览器 TTS 的发音质量取决于系统是否安装日语语音包。
