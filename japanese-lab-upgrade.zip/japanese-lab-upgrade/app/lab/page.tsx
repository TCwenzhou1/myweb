'use client';

import { useMemo, useState } from 'react';
import { GrammarCard } from '@/components/GrammarCard';
import { VocabularyCard } from '@/components/VocabularyCard';
import { grammarData, JLPTLevel, vocabularyData, vocabularyLevels } from '@/lib/japaneseData';
import { useLearningProgress } from '@/lib/useLearningProgress';

type Mode = 'all' | 'jlpt' | 'exam';

export default function LabPage() {
  const [keyword, setKeyword] = useState('');
  const [mode, setMode] = useState<Mode>('all');
  const [selectedLevel, setSelectedLevel] = useState<JLPTLevel | '全部'>('全部');

  const filteredVocabulary = useMemo(() => {
    return vocabularyData.filter((item) => {
      const matchesKeyword =
        keyword.trim() === '' ||
        [item.word, item.kana, item.romaji, item.meaning, item.usageCore, item.examFocus]
          .join(' ')
          .toLowerCase()
          .includes(keyword.toLowerCase());

      const matchesMode =
        mode === 'all'
          ? true
          : mode === 'jlpt'
            ? item.category === 'jlpt'
            : item.category === 'exam';

      const matchesLevel = selectedLevel === '全部' ? true : item.level === selectedLevel;

      return matchesKeyword && matchesMode && matchesLevel;
    });
  }, [keyword, mode, selectedLevel]);

  const filteredGrammar = useMemo(() => {
    return grammarData.filter((item) => {
      const matchesKeyword =
        keyword.trim() === '' ||
        [item.title, item.meaning, item.usage, item.example, item.examTip]
          .join(' ')
          .toLowerCase()
          .includes(keyword.toLowerCase());

      const matchesLevel = selectedLevel === '全部' ? true : item.level === selectedLevel;
      const matchesMode =
        mode === 'all'
          ? true
          : mode === 'jlpt'
            ? item.level === 'N2' || item.level === 'N1'
            : item.level === '考研';

      return matchesKeyword && matchesLevel && matchesMode;
    });
  }, [keyword, mode, selectedLevel]);

  const { progress, stats, toggleLearned, toggleMastered, resetProgress } =
    useLearningProgress(vocabularyData.length);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 md:px-6">
      <div className="mx-auto max-w-7xl">
        <section className="rounded-3xl bg-gradient-to-r from-slate-900 to-slate-700 p-6 text-white shadow-lg md:p-8">
          <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold tracking-wide">
            Japanese Lab · JLPT + 考研日语
          </span>
          <h1 className="mt-4 text-3xl font-bold md:text-4xl">日语学习实验室升级版</h1>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-200 md:text-base">
            现在支持 N1 / N2 / N3 / N4 / N5 与考研日语核心词汇学习。每个词条都包含：
            读音、核心用法、常见搭配、考试提醒、例句，整体交互参考 Moji
            的词卡逻辑，适合刷词、记搭配、做阅读前热身。
          </p>

          <div className="mt-6 grid gap-4 md:grid-cols-4">
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-sm text-slate-200">总词条</p>
              <p className="mt-2 text-2xl font-bold">{stats.totalItems}</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-sm text-slate-200">已学</p>
              <p className="mt-2 text-2xl font-bold">{stats.learnedCount}</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-sm text-slate-200">已掌握</p>
              <p className="mt-2 text-2xl font-bold">{stats.masteredCount}</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-sm text-slate-200">连续学习</p>
              <p className="mt-2 text-2xl font-bold">{stats.streak} 天</p>
            </div>
          </div>

          <div className="mt-6">
            <div className="h-3 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-emerald-400 transition-all"
                style={{ width: `${stats.progressPercent}%` }}
              />
            </div>
            <p className="mt-2 text-sm text-slate-200">掌握进度：{stats.progressPercent}%</p>
          </div>
        </section>

        <section className="mt-6 rounded-3xl bg-white p-5 shadow-sm">
          <div className="grid gap-4 lg:grid-cols-[1.5fr,1fr,1fr,auto]">
            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-slate-800">搜索词条 / 用法</span>
              <input
                value={keyword}
                onChange={(event) => setKeyword(event.target.value)}
                placeholder="输入日语、假名、中文、搭配、作者观点、根拠、把握……"
                className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-slate-500"
              />
            </label>

            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-slate-800">学习模式</span>
              <select
                value={mode}
                onChange={(event) => setMode(event.target.value as Mode)}
                className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none"
              >
                <option value="all">全部</option>
                <option value="jlpt">JLPT 词汇</option>
                <option value="exam">考研核心词汇</option>
              </select>
            </label>

            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-slate-800">等级筛选</span>
              <select
                value={selectedLevel}
                onChange={(event) => setSelectedLevel(event.target.value as JLPTLevel | '全部')}
                className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none"
              >
                <option value="全部">全部</option>
                {vocabularyLevels.map((level) => (
                  <option key={level} value={level}>
                    {level}
                  </option>
                ))}
              </select>
            </label>

            <div className="flex items-end">
              <button
                type="button"
                onClick={resetProgress}
                className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                重置进度
              </button>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            {['all', 'jlpt', 'exam'].map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setMode(item as Mode)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  mode === item
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {item === 'all' ? '全部内容' : item === 'jlpt' ? 'JLPT 专项' : '考研冲刺'}
              </button>
            ))}
          </div>

          <p className="mt-4 text-sm text-slate-500">
            当前显示 {filteredVocabulary.length} 个词条，{filteredGrammar.length} 个语法点。
          </p>
        </section>

        <section className="mt-8">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">核心词汇卡</h2>
              <p className="mt-1 text-sm text-slate-500">
                词条信息更靠近 Moji 的学习体验：词义 + 发音 + 用法 + 搭配 + 例句。
              </p>
            </div>
          </div>

          <div className="grid gap-5 xl:grid-cols-2">
            {filteredVocabulary.map((item) => (
              <VocabularyCard
                key={item.id}
                item={item}
                learned={progress.learnedIds.includes(item.id)}
                mastered={progress.masteredIds.includes(item.id)}
                onToggleLearned={toggleLearned}
                onToggleMastered={toggleMastered}
              />
            ))}
          </div>

          {filteredVocabulary.length === 0 && (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
              没有匹配到词条，换个关键词试试，比如：把握 / 指摘 / 影響 / 顕著
            </div>
          )}
        </section>

        <section className="mt-10">
          <div className="mb-4">
            <h2 className="text-2xl font-bold text-slate-900">高频语法补充</h2>
            <p className="mt-1 text-sm text-slate-500">
              保留原来的语法学习思路，同时补充 N1 / N2 / 考研高频结构。
            </p>
          </div>

          <div className="grid gap-5 lg:grid-cols-2 xl:grid-cols-3">
            {filteredGrammar.map((item) => (
              <GrammarCard key={item.id} item={item} />
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
