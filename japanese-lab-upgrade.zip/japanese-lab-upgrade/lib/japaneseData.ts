// 合并到你现有项目时，建议使用：const vocabularyData = [...旧的N5/N4/N3数据, ...这里新增的N2/N1/考研数据]
export type JLPTLevel = 'N5' | 'N4' | 'N3' | 'N2' | 'N1' | '考研';
export type StudyCategory = 'jlpt' | 'exam';

export interface ExampleSentence {
  jp: string;
  kana: string;
  zh: string;
}

export interface VocabularyItem {
  id: string;
  word: string;
  kana: string;
  romaji: string;
  meaning: string;
  level: JLPTLevel;
  category: StudyCategory;
  partOfSpeech: string;
  pronunciation: string;
  usageCore: string;
  usagePatterns: string[];
  collocations: string[];
  examFocus: string;
  examples: ExampleSentence[];
  tags: string[];
}

export interface GrammarItem {
  id: string;
  title: string;
  level: 'N2' | 'N1' | '考研';
  meaning: string;
  usage: string;
  example: string;
  examTip: string;
}

export const vocabularyLevels: JLPTLevel[] = ['N5', 'N4', 'N3', 'N2', 'N1', '考研'];

export const vocabularyData: VocabularyItem[] = [
  {
    id: 'n2-001',
    word: '影響',
    kana: 'えいきょう',
    romaji: 'eikyou',
    meaning: '影响',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'えい-きょう，注意长音「きょう」要拉开。',
    usageCore: '多用于书面表达，表示对人、事、结果产生作用。',
    usagePatterns: ['〜に影響する', '〜へ影響を与える', '影響が大きい'],
    collocations: ['経済に影響する', '社会へ影響を与える', '悪い影響'],
    examFocus: '阅读里常和「環境」「経済」「社会」搭配，常考因果关系。',
    examples: [
      {
        jp: '気候の変化は農業に大きな影響を与える。',
        kana: 'きこう の へんか は のうぎょう に おおきな えいきょう を あたえる。',
        zh: '气候变化会对农业产生很大影响。'
      },
      {
        jp: 'その事件は人々の考え方に影響した。',
        kana: 'その じけん は ひとびと の かんがえかた に えいきょう した。',
        zh: '那起事件影响了人们的思考方式。'
      }
    ],
    tags: ['高频阅读', '因果', '书面语']
  },
  {
    id: 'n2-002',
    word: '制度',
    kana: 'せいど',
    romaji: 'seido',
    meaning: '制度，体制',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'せい-ど，前长后短。',
    usageCore: '表示社会、组织或国家层面的规则体系。',
    usagePatterns: ['制度を導入する', '制度を見直す', '制度が整っている'],
    collocations: ['教育制度', '社会制度', '新しい制度'],
    examFocus: '考研阅读中常和教育、福祉、雇用主题一起出现。',
    examples: [
      {
        jp: '新しい制度を導入する前に十分な議論が必要だ。',
        kana: 'あたらしい せいど を どうにゅう する まえ に じゅうぶんな ぎろん が ひつよう だ。',
        zh: '在引入新制度之前需要充分讨论。'
      },
      {
        jp: 'その国の教育制度は地域によって異なる。',
        kana: 'その くに の きょういく せいど は ちいき に よって ことなる。',
        zh: '那个国家的教育制度因地区而异。'
      }
    ],
    tags: ['社会主题', '制度类', '书面语']
  },
  {
    id: 'n2-003',
    word: '傾向',
    kana: 'けいこう',
    romaji: 'keikou',
    meaning: '倾向，趋势',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'けい-こう，两个长音都要读满。',
    usageCore: '表示某种持续出现的方向、特点或变化趋势。',
    usagePatterns: ['〜の傾向がある', '増加傾向', '〜する傾向にある'],
    collocations: ['若者の傾向', '消費の傾向', '保守的な傾向'],
    examFocus: '常与图表、社会调查、消费行为一起出现。',
    examples: [
      {
        jp: '最近は一人で旅行する人が増える傾向にある。',
        kana: 'さいきん は ひとり で りょこう する ひと が ふえる けいこう に ある。',
        zh: '最近独自旅行的人有增加的趋势。'
      },
      {
        jp: 'このデータから都市部に集中する傾向が見える。',
        kana: 'この データ から としぶ に しゅうちゅう する けいこう が みえる。',
        zh: '从这组数据可以看出向城市集中趋势。'
      }
    ],
    tags: ['趋势', '数据阅读', '高频']
  },
  {
    id: 'n2-004',
    word: '現状',
    kana: 'げんじょう',
    romaji: 'genjou',
    meaning: '现状，目前情况',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'げん-じょう，后半部分是长音。',
    usageCore: '用于说明当前状态，常与分析、问题意识一起出现。',
    usagePatterns: ['現状では', '現状を把握する', '現状の問題点'],
    collocations: ['現状分析', '現状維持', '現状認識'],
    examFocus: '写作和阅读都很常见，常作为论述的起点。',
    examples: [
      {
        jp: '現状ではこの計画を実行するのは難しい。',
        kana: 'げんじょう では この けいかく を じっこう する の は むずかしい。',
        zh: '就目前情况而言，很难执行这个计划。'
      },
      {
        jp: 'まず現状を正確に把握することが大切だ。',
        kana: 'まず げんじょう を せいかく に はあく する こと が たいせつ だ。',
        zh: '首先准确把握现状很重要。'
      }
    ],
    tags: ['写作常用', '问题分析', '书面语']
  },
  {
    id: 'n2-005',
    word: '拡大',
    kana: 'かくだい',
    romaji: 'kakudai',
    meaning: '扩大，扩张',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'かく-だい，第二拍发音清楚。',
    usageCore: '表示范围、规模、影响力等变大。',
    usagePatterns: ['規模を拡大する', '被害が拡大する', '拡大傾向'],
    collocations: ['市場を拡大する', '感染拡大', '需要拡大'],
    examFocus: '新闻、社会、经济类文本的常见词。',
    examples: [
      {
        jp: '企業は海外市場への進出を通じて事業を拡大した。',
        kana: 'きぎょう は かいがい しじょう への しんしゅつ を つうじて じぎょう を かくだい した。',
        zh: '企业通过进军海外市场扩大了业务。'
      },
      {
        jp: '被害の拡大を防ぐため、早急な対応が求められる。',
        kana: 'ひがい の かくだい を ふせぐ ため、そうきゅう な たいおう が もとめられる。',
        zh: '为了防止损害扩大，需要迅速应对。'
      }
    ],
    tags: ['经济', '社会', '高频']
  },
  {
    id: 'n2-006',
    word: '目的',
    kana: 'もくてき',
    romaji: 'mokuteki',
    meaning: '目的',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'もく-てき，后半清晰收音。',
    usageCore: '说明行为、制度或研究的目标。',
    usagePatterns: ['〜を目的として', '目的を達成する', '目的意識'],
    collocations: ['教育の目的', '利用目的', '明確な目的'],
    examFocus: '说明文里常用于定义段和结论句。',
    examples: [
      {
        jp: 'この制度は高齢者の生活を支えることを目的としている。',
        kana: 'この せいど は こうれいしゃ の せいかつ を ささえる こと を もくてき として いる。',
        zh: '这一制度以支持老年人的生活为目的。'
      },
      {
        jp: '研究の目的を明確にする必要がある。',
        kana: 'けんきゅう の もくてき を めいかく に する ひつよう が ある。',
        zh: '有必要明确研究的目的。'
      }
    ],
    tags: ['定义句', '高频', '写作']
  },
  {
    id: 'n2-007',
    word: '費やす',
    kana: 'ついやす',
    romaji: 'tsuiyasu',
    meaning: '花费，耗费（时间/精力/金钱）',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '动词',
    pronunciation: 'つ-い-や-す，注意不是「つかう」。',
    usageCore: '强调为某事投入较多资源。',
    usagePatterns: ['時間を費やす', '努力を費やす', '多額の費用を費やす'],
    collocations: ['研究に費やす', '準備に費やす', '人生を費やす'],
    examFocus: '文章里常带有“投入巨大”的语气色彩。',
    examples: [
      {
        jp: '彼はその研究に十年以上を費やした。',
        kana: 'かれ は その けんきゅう に じゅうねん いじょう を ついやした。',
        zh: '他为那项研究花费了十多年。'
      },
      {
        jp: '問題の解決に多くの時間を費やしている。',
        kana: 'もんだい の かいけつ に おおく の じかん を ついやして いる。',
        zh: '正在为解决问题耗费大量时间。'
      }
    ],
    tags: ['动词', '投入', '书面表达']
  },
  {
    id: 'n2-008',
    word: '維持',
    kana: 'いじ',
    romaji: 'iji',
    meaning: '维持',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'い-じ，短而稳。',
    usageCore: '表示保持现有状态、水平或关系。',
    usagePatterns: ['現状を維持する', '秩序を維持する', '維持が難しい'],
    collocations: ['体力を維持する', '関係維持', '品質維持'],
    examFocus: '经常和「向上」「改善」对照出现。',
    examples: [
      {
        jp: '人口が減少する中で地域社会を維持するのは容易ではない。',
        kana: 'じんこう が げんしょう する なか で ちいき しゃかい を いじ する の は ようい では ない。',
        zh: '在人口减少的情况下，维持地区社会并不容易。'
      },
      {
        jp: '健康を維持するためには適度な運動が必要だ。',
        kana: 'けんこう を いじ する ため に は てきど な うんどう が ひつよう だ。',
        zh: '为了维持健康，需要适度运动。'
      }
    ],
    tags: ['对比词', '常考', '书面语']
  },
  {
    id: 'n2-009',
    word: '課題',
    kana: 'かだい',
    romaji: 'kadai',
    meaning: '课题，问题，任务',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'か-だい，后半长音明显。',
    usageCore: '既可指作业任务，也常指社会/研究层面的课题。',
    usagePatterns: ['課題を抱える', '今後の課題', '課題に取り組む'],
    collocations: ['教育課題', '共通の課題', '重要な課題'],
    examFocus: '考研阅读里非常高频，多用第二层“社会问题”的意思。',
    examples: [
      {
        jp: '少子高齢化は日本社会の大きな課題である。',
        kana: 'しょうし こうれいか は にほん しゃかい の おおきな かだい で ある。',
        zh: '少子高龄化是日本社会的一大课题。'
      },
      {
        jp: '私たちはその課題にどう向き合うべきだろうか。',
        kana: 'わたしたち は その かだい に どう むきあう べき だろう か。',
        zh: '我们应该如何面对这个课题呢？'
      }
    ],
    tags: ['超高频', '社会问题', '写作']
  },
  {
    id: 'n2-010',
    word: '重視',
    kana: 'じゅうし',
    romaji: 'juushi',
    meaning: '重视',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'じゅう-し，首拍长音。',
    usageCore: '强调将某个要素放在重要位置。',
    usagePatterns: ['〜を重視する', '重視される', '効率を重視する'],
    collocations: ['個性を重視する', '結果を重視する', '安全を重視する'],
    examFocus: '常和教育理念、企业经营、价值判断搭配。',
    examples: [
      {
        jp: '最近の教育では思考力が重視されている。',
        kana: 'さいきん の きょういく では しこうりょく が じゅうし されて いる。',
        zh: '最近的教育中，思考能力受到重视。'
      },
      {
        jp: '企業は短期的な利益より信頼を重視すべきだ。',
        kana: 'きぎょう は たんきてき な りえき より しんらい を じゅうし すべき だ。',
        zh: '企业比起短期利益更应重视信誉。'
      }
    ],
    tags: ['价值判断', '高频', '写作']
  },
  {
    id: 'n2-011',
    word: '明らか',
    kana: 'あきらか',
    romaji: 'akiraka',
    meaning: '明显，明确',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '形容动词',
    pronunciation: 'あ-き-ら-か，平稳念出四拍。',
    usageCore: '用于说明事实、差异、原因等变得清楚。',
    usagePatterns: ['明らかになる', '明らかにする', '明らかな違い'],
    collocations: ['事実が明らかになる', '原因を明らかにする', '明らかな変化'],
    examFocus: '论文摘要、调查报告、说明文中都很高频。',
    examples: [
      {
        jp: '調査の結果、新たな問題点が明らかになった。',
        kana: 'ちょうさ の けっか、あらたな もんだいてん が あきらか に なった。',
        zh: '调查结果显示，新的问题点变得明确了。'
      },
      {
        jp: '両者の考え方には明らかな違いがある。',
        kana: 'りょうしゃ の かんがえかた に は あきらかな ちがい が ある。',
        zh: '两者的思考方式有明显差异。'
      }
    ],
    tags: ['说明文', '常考', '结果表达']
  },
  {
    id: 'n2-012',
    word: '実態',
    kana: 'じったい',
    romaji: 'jittai',
    meaning: '实际情况，真实状态',
    level: 'N2',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'じっ-たい，促音要短促有力。',
    usageCore: '强调与表面说法不同的真实情况。',
    usagePatterns: ['実態を調べる', '実態が見えにくい', '実態調査'],
    collocations: ['生活実態', '雇用実態', '実態把握'],
    examFocus: '常出现在社会调查、纪实和批判性文章中。',
    examples: [
      {
        jp: '外国人労働者の実態を正しく理解する必要がある。',
        kana: 'がいこくじん ろうどうしゃ の じったい を ただしく りかい する ひつよう が ある。',
        zh: '有必要正确理解外国劳动者的实际情况。'
      },
      {
        jp: '表面だけでなく、地域の実態を見るべきだ。',
        kana: 'ひょうめん だけ で なく、ちいき の じったい を みる べき だ。',
        zh: '不应只看表面，而应看到地区的实际情况。'
      }
    ],
    tags: ['调查类', '社会议题', '高频']
  },

  {
    id: 'n1-001',
    word: '顕著',
    kana: 'けんちょ',
    romaji: 'kencho',
    meaning: '显著，明显',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '形容动词',
    pronunciation: 'けん-ちょ，第二拍要短。',
    usageCore: '书面程度高，用于突出变化或差异非常明显。',
    usagePatterns: ['顕著な変化', '顕著に表れる', '差が顕著だ'],
    collocations: ['地域差が顕著', '顕著な傾向', '成果が顕著に現れる'],
    examFocus: 'N1阅读与学术说明文常见，替代普通的「明らか」。',
    examples: [
      {
        jp: '都市と地方の格差は近年ますます顕著になっている。',
        kana: 'とし と ちほう の かくさ は きんねん ますます けんちょ に なって いる。',
        zh: '近年城市与地方的差距越来越显著。'
      },
      {
        jp: 'その違いは若い世代において特に顕著だ。',
        kana: 'その ちがい は わかい せだい に おいて とくに けんちょ だ。',
        zh: '那种差异在年轻一代中尤为显著。'
      }
    ],
    tags: ['N1高频', '学术书面', '替换词']
  },
  {
    id: 'n1-002',
    word: '促進',
    kana: 'そくしん',
    romaji: 'sokushin',
    meaning: '促进，推进',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'そく-しん，促音短。',
    usageCore: '常用于政策、交流、发展等正式语境。',
    usagePatterns: ['交流を促進する', '促進策', '利用促進'],
    collocations: ['地域活性化を促進する', '理解促進', '成長促進'],
    examFocus: '政策类文本、作文正式表达里非常好用。',
    examples: [
      {
        jp: '政府は再生可能エネルギーの利用を促進している。',
        kana: 'せいふ は さいせい かのう エネルギー の りよう を そくしん して いる。',
        zh: '政府正在促进可再生能源的利用。'
      },
      {
        jp: '文化交流は相互理解を促進する役割を果たす。',
        kana: 'ぶんか こうりゅう は そうご りかい を そくしん する やくわり を はたす。',
        zh: '文化交流起到促进相互理解的作用。'
      }
    ],
    tags: ['政策类', '作文高级词', 'N1']
  },
  {
    id: 'n1-003',
    word: '見解',
    kana: 'けんかい',
    romaji: 'kenkai',
    meaning: '见解，看法',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'けん-かい，尾音拉开。',
    usageCore: '比「意見」更正式，常用于学者、机构、作者观点。',
    usagePatterns: ['見解を示す', '〜という見解', '見解の相違'],
    collocations: ['政府の見解', '専門家の見解', '公式見解'],
    examFocus: '阅读主旨题中经常用来引出作者或机构态度。',
    examples: [
      {
        jp: '専門家の間でもその点について見解が分かれている。',
        kana: 'せんもんか の あいだ でも その てん について けんかい が わかれて いる。',
        zh: '即使在专家之间，对于这一点的见解也存在分歧。'
      },
      {
        jp: '筆者は教育の役割について独自の見解を示している。',
        kana: 'ひっしゃ は きょういく の やくわり について どくじ の けんかい を しめして いる。',
        zh: '作者就教育的作用提出了独特见解。'
      }
    ],
    tags: ['观点题', '阅读理解', '书面']
  },
  {
    id: 'n1-004',
    word: '枠組み',
    kana: 'わくぐみ',
    romaji: 'wakugumi',
    meaning: '框架，体系',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'わ-く-ぐ-み，四拍分明。',
    usageCore: '指思考框架、制度结构、分析体系。',
    usagePatterns: ['枠組みを作る', '既存の枠組み', '新たな枠組み'],
    collocations: ['制度の枠組み', '分析の枠組み', '国際的枠組み'],
    examFocus: '学术文章和社会评论中频繁出现。',
    examples: [
      {
        jp: '従来の枠組みではこの問題を十分に説明できない。',
        kana: 'じゅうらい の わくぐみ では この もんだい を じゅうぶん に せつめい できない。',
        zh: '用传统框架无法充分说明这个问题。'
      },
      {
        jp: '国際協力の新たな枠組みが求められている。',
        kana: 'こくさい きょうりょく の あらたな わくぐみ が もとめられて いる。',
        zh: '人们正在寻求国际合作的新框架。'
      }
    ],
    tags: ['抽象名词', '学术阅读', 'N1']
  },
  {
    id: 'n1-005',
    word: '担う',
    kana: 'になう',
    romaji: 'ninau',
    meaning: '承担，担负',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '动词',
    pronunciation: 'に-な-う，尾音长。',
    usageCore: '多用于承担责任、角色、功能，书面色彩强。',
    usagePatterns: ['役割を担う', '将来を担う', '責任を担う'],
    collocations: ['社会を担う若者', '中核を担う', '重要な役割を担う'],
    examFocus: '阅读和作文都很常见，常与“若者”“教育”搭配。',
    examples: [
      {
        jp: '若者は次の時代を担う存在だと言われている。',
        kana: 'わかもの は つぎ の じだい を になう そんざい だ と いわれて いる。',
        zh: '年轻人被认为是肩负下一个时代的存在。'
      },
      {
        jp: '地域の学校はコミュニティの中心的役割を担っている。',
        kana: 'ちいき の がっこう は コミュニティ の ちゅうしんてき やくわり を になって いる。',
        zh: '地区学校承担着社区核心角色。'
      }
    ],
    tags: ['作文加分', '责任', '高频']
  },
  {
    id: 'n1-006',
    word: '過程',
    kana: 'かてい',
    romaji: 'katei',
    meaning: '过程',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词',
    pronunciation: 'か-てい，后长音。',
    usageCore: '强调变化、形成或解决问题的过程本身。',
    usagePatterns: ['形成の過程', '過程において', '発達過程'],
    collocations: ['学習過程', '議論の過程', '変化の過程'],
    examFocus: '常出现在论证过程、研究过程、成长过程描述中。',
    examples: [
      {
        jp: '結果だけでなく、その過程を評価することが大切だ。',
        kana: 'けっか だけ で なく、その かてい を ひょうか する こと が たいせつ だ。',
        zh: '不仅结果，评价其过程也很重要。'
      },
      {
        jp: '都市化の過程で多くの伝統が失われた。',
        kana: 'としか の かてい で おおく の でんとう が うしなわれた。',
        zh: '在城市化过程中，许多传统消失了。'
      }
    ],
    tags: ['论证', '过程题', 'N1']
  },
  {
    id: 'n1-007',
    word: '実践',
    kana: 'じっせん',
    romaji: 'jissen',
    meaning: '实践，实行',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'じっ-せん，促音清晰。',
    usageCore: '表示将理论、方法、理念付诸实施。',
    usagePatterns: ['理論を実践する', '実践例', '実践的な知識'],
    collocations: ['教育実践', '実践力', '実践活動'],
    examFocus: '教育类、研究类、方法论文章高频。',
    examples: [
      {
        jp: '知識を社会で実践できる人材が求められている。',
        kana: 'ちしき を しゃかい で じっせん できる じんざい が もとめられて いる。',
        zh: '社会需要能够将知识付诸实践的人才。'
      },
      {
        jp: '理論と実践の両方を結びつける必要がある。',
        kana: 'りろん と じっせん の りょうほう を むすびつける ひつよう が ある。',
        zh: '有必要把理论和实践两者结合起来。'
      }
    ],
    tags: ['教育类', '理论实践', '高频']
  },
  {
    id: 'n1-008',
    word: '検証',
    kana: 'けんしょう',
    romaji: 'kenshou',
    meaning: '验证，检验',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'けん-しょう，后半长音。',
    usageCore: '多指对观点、假设、政策、效果进行验证。',
    usagePatterns: ['効果を検証する', '検証結果', '仮説を検証する'],
    collocations: ['実証的に検証する', '政策検証', '検証作業'],
    examFocus: '论文摘要、实验说明、研究方法题中常见。',
    examples: [
      {
        jp: 'その仮説が正しいかどうかを検証する必要がある。',
        kana: 'その かせつ が ただしい か どうか を けんしょう する ひつよう が ある。',
        zh: '有必要验证那个假设是否正确。'
      },
      {
        jp: '新制度の効果は今後さらに検証されるべきだ。',
        kana: 'しんせいど の こうか は こんご さらに けんしょう される べき だ。',
        zh: '新制度的效果今后还应进一步验证。'
      }
    ],
    tags: ['学术', '研究', 'N1']
  },
  {
    id: 'n1-009',
    word: '転換',
    kana: 'てんかん',
    romaji: 'tenkan',
    meaning: '转换，转变',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'てん-かん，尾音收紧。',
    usageCore: '表示方向、政策、思路、模式等的改变。',
    usagePatterns: ['発想を転換する', '政策転換', '大きな転換点'],
    collocations: ['価値観の転換', '方向転換', '意識の転換'],
    examFocus: '评论文中常用来描述时代变化或观念变化。',
    examples: [
      {
        jp: 'これからは量より質を重視する方向への転換が必要だ。',
        kana: 'これから は りょう より しつ を じゅうし する ほうこう への てんかん が ひつよう だ。',
        zh: '今后有必要转向重视质量而非数量。'
      },
      {
        jp: 'その経験が彼の人生の転換点になった。',
        kana: 'その けいけん が かれ の じんせい の てんかんてん に なった。',
        zh: '那段经历成为了他人生的转折点。'
      }
    ],
    tags: ['转折', '观点变化', 'N1']
  },
  {
    id: 'n1-010',
    word: '一貫',
    kana: 'いっかん',
    romaji: 'ikkan',
    meaning: '一贯，始终一致',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / 副词 / サ变',
    pronunciation: 'いっ-かん，促音短。',
    usageCore: '表示立场、方针、态度、内容前后一致。',
    usagePatterns: ['一貫して', '一貫性がある', '方針を一貫させる'],
    collocations: ['一貫した態度', '一貫した方針', '論理の一貫性'],
    examFocus: '主旨题、论证结构题中很好用。',
    examples: [
      {
        jp: '彼は教育の平等を一貫して主張してきた。',
        kana: 'かれ は きょういく の びょうどう を いっかん して しゅちょう して きた。',
        zh: '他始终一贯地坚持教育平等。'
      },
      {
        jp: 'この文章には論理の一貫性がある。',
        kana: 'この ぶんしょう に は ろんり の いっかんせい が ある。',
        zh: '这篇文章在逻辑上具有一致性。'
      }
    ],
    tags: ['结构题', '逻辑', 'N1']
  },
  {
    id: 'n1-011',
    word: '不可欠',
    kana: 'ふかけつ',
    romaji: 'fukaketsu',
    meaning: '不可或缺',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '形容动词',
    pronunciation: 'ふ-か-けつ，结尾利落。',
    usageCore: '表示某事物必不可少，正式且常见。',
    usagePatterns: ['〜に不可欠だ', '不可欠な要素', '不可欠とされる'],
    collocations: ['社会に不可欠', '成長に不可欠', '不可欠な存在'],
    examFocus: '作文结论句、说明文归纳句高频。',
    examples: [
      {
        jp: '多様な価値観を理解する姿勢は現代社会に不可欠だ。',
        kana: 'たよう な かちかん を りかい する しせい は げんだい しゃかい に ふかけつ だ。',
        zh: '理解多元价值观的态度对现代社会不可或缺。'
      },
      {
        jp: '地方の交通手段としてバスは不可欠な存在である。',
        kana: 'ちほう の こうつう しゅだん として バス は ふかけつ な そんざい で ある。',
        zh: '作为地方交通手段，公交是不可或缺的存在。'
      }
    ],
    tags: ['高阶表达', '结论句', '常考']
  },
  {
    id: 'n1-012',
    word: '示唆',
    kana: 'しさ',
    romaji: 'shisa',
    meaning: '启示，暗示',
    level: 'N1',
    category: 'jlpt',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'し-さ，两拍干净。',
    usageCore: '表示间接提示某种意义、方向或结论。',
    usagePatterns: ['〜を示唆する', '示唆に富む', '結果が示唆する'],
    collocations: ['重要な示唆', '研究が示唆する', '将来を示唆する'],
    examFocus: '推论题、研究结论题中非常常见。',
    examples: [
      {
        jp: 'この調査結果は教育格差の拡大を示唆している。',
        kana: 'この ちょうさ けっか は きょういく かくさ の かくだい を しさ して いる。',
        zh: '这项调查结果暗示了教育差距正在扩大。'
      },
      {
        jp: '彼の発言は社会の変化を示唆するものだった。',
        kana: 'かれ の はつげん は しゃかい の へんか を しさ する もの だった。',
        zh: '他的发言暗示了社会的变化。'
      }
    ],
    tags: ['推论', '研究结论', 'N1']
  },

  {
    id: 'exam-001',
    word: '把握',
    kana: 'はあく',
    romaji: 'haaku',
    meaning: '把握，掌握',
    level: '考研',
    category: 'exam',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'は-あ-く，中间长音要自然过渡。',
    usageCore: '高频用于“准确掌握情况、重点、数据、主旨”。',
    usagePatterns: ['実態を把握する', '要点を把握する', '正確に把握する'],
    collocations: ['現状把握', '状況を把握する', '全体を把握する'],
    examFocus: '做阅读时经常对应“主旨把握”“信息把握”类题眼。',
    examples: [
      {
        jp: 'まず文章全体の流れを把握してから細部を見るべきだ。',
        kana: 'まず ぶんしょう ぜんたい の ながれ を はあく して から さいぶ を みる べき だ。',
        zh: '应先把握文章整体脉络，再看细节。'
      },
      {
        jp: '現状を正確に把握しなければ対策は立てられない。',
        kana: 'げんじょう を せいかく に はあく しなければ たいさく は たてられない。',
        zh: '如果不能准确把握现状，就无法制定对策。'
      }
    ],
    tags: ['考研核心', '阅读技巧', '超高频']
  },
  {
    id: 'exam-002',
    word: '指摘',
    kana: 'してき',
    romaji: 'shiteki',
    meaning: '指出，指摘',
    level: '考研',
    category: 'exam',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'し-てき，读得利落。',
    usageCore: '表示作者、学者、文章对问题或事实进行指出。',
    usagePatterns: ['問題点を指摘する', '著者が指摘する', '以前から指摘されている'],
    collocations: ['欠点を指摘する', '鋭く指摘する', '繰り返し指摘される'],
    examFocus: '题干里经常会问“作者指出了什么”。',
    examples: [
      {
        jp: '筆者は現代教育の問題点を鋭く指摘している。',
        kana: 'ひっしゃ は げんだい きょういく の もんだいてん を するどく してき して いる。',
        zh: '作者尖锐地指出了现代教育的问题点。'
      },
      {
        jp: '以前からその危険性が指摘されてきた。',
        kana: 'いぜん から その きけんせい が してき されて きた。',
        zh: '其危险性从以前开始就一直被指出。'
      }
    ],
    tags: ['作者观点', '阅读题眼', '高频']
  },
  {
    id: 'exam-003',
    word: '捉える',
    kana: 'とらえる',
    romaji: 'toraeru',
    meaning: '把握，捕捉，看待',
    level: '考研',
    category: 'exam',
    partOfSpeech: '动词',
    pronunciation: 'と-ら-え-る，注意「え」不要吞掉。',
    usageCore: '除“抓住”外，阅读里更常表示“理解、看待某事物”。',
    usagePatterns: ['本質を捉える', '〜と捉える', '多面的に捉える'],
    collocations: ['問題を捉える', '変化を捉える', '正しく捉える'],
    examFocus: '主旨题和作者态度题的核心动词。',
    examples: [
      {
        jp: '現象だけでなく背景まで捉える必要がある。',
        kana: 'げんしょう だけ で なく はいけい まで とらえる ひつよう が ある。',
        zh: '不仅要看到现象，还要把握其背景。'
      },
      {
        jp: '筆者は失敗を成長の機会として捉えている。',
        kana: 'ひっしゃ は しっぱい を せいちょう の きかい として とらえて いる。',
        zh: '作者将失败看作成长的机会。'
      }
    ],
    tags: ['主旨理解', '态度题', '高频']
  },
  {
    id: 'exam-004',
    word: '論じる',
    kana: 'ろんじる',
    romaji: 'ronjiru',
    meaning: '论述，讨论',
    level: '考研',
    category: 'exam',
    partOfSpeech: '动词',
    pronunciation: 'ろん-じ-る，鼻音后接浊音要清楚。',
    usageCore: '用于正式讨论某个主题，比「話す」高级得多。',
    usagePatterns: ['〜について論じる', '詳しく論じる', '多角的に論じる'],
    collocations: ['社会問題を論じる', '教育を論じる', '歴史的に論じる'],
    examFocus: '经常出现在文章目的、结构题中。',
    examples: [
      {
        jp: 'この文章は都市化の影響について論じている。',
        kana: 'この ぶんしょう は としか の えいきょう について ろんじて いる。',
        zh: '这篇文章论述了城市化的影响。'
      },
      {
        jp: '筆者はその問題を多角的に論じている。',
        kana: 'ひっしゃ は その もんだい を たかくてき に ろんじて いる。',
        zh: '作者从多角度论述了这个问题。'
      }
    ],
    tags: ['文章结构', '论述文', '核心']
  },
  {
    id: 'exam-005',
    word: '見なす',
    kana: 'みなす',
    romaji: 'minasu',
    meaning: '看作，视为',
    level: '考研',
    category: 'exam',
    partOfSpeech: '动词',
    pronunciation: 'み-な-す，短促有力。',
    usageCore: '表示将A判断为B，常用于观点和定义。',
    usagePatterns: ['AをBと見なす', '〜と見なされる', '一般に見なす'],
    collocations: ['成功と見なす', '重要と見なす', '例外と見なす'],
    examFocus: '定义题、态度题、作者立场题高频。',
    examples: [
      {
        jp: '彼は失敗を貴重な経験と見なしている。',
        kana: 'かれ は しっぱい を きちょう な けいけん と みなして いる。',
        zh: '他把失败视为宝贵经验。'
      },
      {
        jp: 'その行為は社会的に問題があると見なされる。',
        kana: 'その こうい は しゃかいてき に もんだい が ある と みなされる。',
        zh: '那种行为被视为在社会层面有问题。'
      }
    ],
    tags: ['观点判断', '定义', '高频']
  },
  {
    id: 'exam-006',
    word: '裏付ける',
    kana: 'うらづける',
    romaji: 'urazukeru',
    meaning: '证实，佐证',
    level: '考研',
    category: 'exam',
    partOfSpeech: '动词',
    pronunciation: 'う-ら-づ-け-る，浊音要清楚。',
    usageCore: '表示某数据、事实、例子对观点形成支撑。',
    usagePatterns: ['データが裏付ける', '事実に裏付けられる', '根拠を裏付ける'],
    collocations: ['研究結果が裏付ける', '証拠に裏付けられる', '仮説を裏付ける'],
    examFocus: '推论题和论证结构题核心词。',
    examples: [
      {
        jp: 'その主張は多くの調査結果によって裏付けられている。',
        kana: 'その しゅちょう は おおく の ちょうさ けっか に よって うらづけられて いる。',
        zh: '那个主张被许多调查结果所证实。'
      },
      {
        jp: '具体例が筆者の考えを裏付けている。',
        kana: 'ぐたいれい が ひっしゃ の かんがえ を うらづけて いる。',
        zh: '具体例佐证了作者的观点。'
      }
    ],
    tags: ['论证', '佐证', '高频']
  },
  {
    id: 'exam-007',
    word: '妥当',
    kana: 'だとう',
    romaji: 'datou',
    meaning: '妥当，恰当',
    level: '考研',
    category: 'exam',
    partOfSpeech: '形容动词',
    pronunciation: 'だ-とう，后长音。',
    usageCore: '表示评价、判断、解释是否合理。',
    usagePatterns: ['妥当な判断', '妥当である', '妥当性がある'],
    collocations: ['妥当な結論', '妥当な評価', '妥当性を欠く'],
    examFocus: '选项判断题非常实用。',
    examples: [
      {
        jp: 'この結論は一定の条件の下では妥当だと言える。',
        kana: 'この けつろん は いってい の じょうけん の もと では だとう だ と いえる。',
        zh: '可以说这个结论在一定条件下是妥当的。'
      },
      {
        jp: 'その説明は一見妥当だが、十分ではない。',
        kana: 'その せつめい は いっけん だとう だ が、じゅうぶん では ない。',
        zh: '那个解释乍看之下妥当，但并不充分。'
      }
    ],
    tags: ['选项分析', '评价', '高频']
  },
  {
    id: 'exam-008',
    word: '妨げる',
    kana: 'さまたげる',
    romaji: 'samatageru',
    meaning: '妨碍，阻碍',
    level: '考研',
    category: 'exam',
    partOfSpeech: '动词',
    pronunciation: 'さ-ま-た-げ-る，节奏均匀。',
    usageCore: '书面语，表示某因素对发展、理解、交流形成阻碍。',
    usagePatterns: ['発展を妨げる', '理解を妨げる', '〜を妨げない'],
    collocations: ['成長を妨げる', '交通を妨げる', '要因を妨げる'],
    examFocus: '社会问题、教育、沟通主题文章高频。',
    examples: [
      {
        jp: '過度な競争は子どもの主体性を妨げることがある。',
        kana: 'かど な きょうそう は こども の しゅたいせい を さまたげる こと が ある。',
        zh: '过度竞争有时会妨碍孩子的主体性。'
      },
      {
        jp: '偏見は相互理解を妨げる大きな要因だ。',
        kana: 'へんけん は そうご りかい を さまたげる おおきな よういん だ。',
        zh: '偏见是妨碍相互理解的重要因素。'
      }
    ],
    tags: ['社会问题', '阻碍', '高频']
  },
  {
    id: 'exam-009',
    word: '根拠',
    kana: 'こんきょ',
    romaji: 'konkyo',
    meaning: '根据，依据',
    level: '考研',
    category: 'exam',
    partOfSpeech: '名词',
    pronunciation: 'こん-きょ，尾音轻短。',
    usageCore: '表示判断、主张、推论的依据。',
    usagePatterns: ['根拠に基づく', '根拠を示す', '根拠が乏しい'],
    collocations: ['科学的根拠', '十分な根拠', '法的根拠'],
    examFocus: '选项题中常考“有无根据”“根据是否充分”。',
    examples: [
      {
        jp: 'その主張には十分な根拠が示されていない。',
        kana: 'その しゅちょう に は じゅうぶんな こんきょ が しめされて いない。',
        zh: '那个主张没有给出充分依据。'
      },
      {
        jp: '私たちは感情ではなく根拠に基づいて判断すべきだ。',
        kana: 'わたしたち は かんじょう では なく こんきょ に もとづいて はんだん すべき だ。',
        zh: '我们应基于依据而不是感情做判断。'
      }
    ],
    tags: ['论证', '选项题', '超高频']
  },
  {
    id: 'exam-010',
    word: '先行',
    kana: 'せんこう',
    romaji: 'senkou',
    meaning: '先行，优先于；先行研究',
    level: '考研',
    category: 'exam',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'せん-こう，后长音。',
    usageCore: '学术文和评论文中表示先一步展开或已存在的相关研究。',
    usagePatterns: ['先行研究', '〜が先行する', '意識が先行する'],
    collocations: ['先行事例', '先行投資', '先行条件'],
    examFocus: '学术说明文里见到率很高。',
    examples: [
      {
        jp: 'このテーマについては多くの先行研究がある。',
        kana: 'この テーマ について は おおく の せんこう けんきゅう が ある。',
        zh: '关于这个主题已经有很多先行研究。'
      },
      {
        jp: '結果ばかりを求める意識が先行している。',
        kana: 'けっか ばかり を もとめる いしき が せんこう して いる。',
        zh: '只追求结果的意识走在前面了。'
      }
    ],
    tags: ['学术文', '研究', '高频']
  },
  {
    id: 'exam-011',
    word: '有効',
    kana: 'ゆうこう',
    romaji: 'yuukou',
    meaning: '有效',
    level: '考研',
    category: 'exam',
    partOfSpeech: '形容动词',
    pronunciation: 'ゆう-こう，双长音。',
    usageCore: '表示方法、对策、制度有效可行。',
    usagePatterns: ['有効な手段', '有効に活用する', '有効性を高める'],
    collocations: ['有効な対策', '有効利用', '有効性の検証'],
    examFocus: '对策题、结论句、政策说明都高频。',
    examples: [
      {
        jp: '地域の活性化には住民参加が有効だと考えられる。',
        kana: 'ちいき の かっせいか に は じゅうみん さんか が ゆうこう だ と かんがえられる。',
        zh: '一般认为居民参与对地区振兴是有效的。'
      },
      {
        jp: 'その方法がすべての場面で有効とは限らない。',
        kana: 'その ほうほう が すべて の ばめん で ゆうこう と は かぎらない。',
        zh: '那种方法并不一定在所有场景都有效。'
      }
    ],
    tags: ['对策', '结论', '高频']
  },
  {
    id: 'exam-012',
    word: '適応',
    kana: 'てきおう',
    romaji: 'tekiou',
    meaning: '适应',
    level: '考研',
    category: 'exam',
    partOfSpeech: '名词 / サ变',
    pronunciation: 'てき-おう，后长音。',
    usageCore: '多指个体、制度、组织对环境变化作出适应。',
    usagePatterns: ['環境に適応する', '社会適応', '適応能力'],
    collocations: ['変化に適応する', '適応力を高める', '新環境に適応する'],
    examFocus: '教育、心理、社会变迁话题高频。',
    examples: [
      {
        jp: '人は環境の変化に適応しながら生きている。',
        kana: 'ひと は かんきょう の へんか に てきおう しながら いきて いる。',
        zh: '人是一边适应环境变化一边生活的。'
      },
      {
        jp: '新しい技術に適応できない企業は生き残れない。',
        kana: 'あたらしい ぎじゅつ に てきおう できない きぎょう は いきのこれない。',
        zh: '无法适应新技术的企业无法生存。'
      }
    ],
    tags: ['变化', '教育心理', '高频']
  }
];

export const grammarData: GrammarItem[] = [
  {
    id: 'g-001',
    title: '〜にすぎない',
    level: 'N2',
    meaning: '只不过，仅仅',
    usage: '名词 / 普通形 + にすぎない。用来降低评价或限定范围。',
    example: 'それは一つの例にすぎない。/ 那只不过是一个例子。',
    examTip: '常用于作者弱化表面现象，提示不要过度解读。'
  },
  {
    id: 'g-002',
    title: '〜にほかならない',
    level: 'N1',
    meaning: '无非就是，正是',
    usage: '名词 + にほかならない。用于强烈下定义。',
    example: '教育とは人間理解の営みにほかならない。/ 教育无非就是理解人的活动。',
    examTip: '很适合判断作者核心定义。'
  },
  {
    id: 'g-003',
    title: '〜をめぐって',
    level: '考研',
    meaning: '围绕……',
    usage: '名词 + をめぐって。表示围绕某问题展开讨论、对立、争论。',
    example: '少子化対策をめぐって議論が続いている。/ 围绕少子化对策的讨论仍在继续。',
    examTip: '新闻类、社会议题类文章高频。'
  },
  {
    id: 'g-004',
    title: '〜ないことには',
    level: 'N1',
    meaning: '如果不……就……',
    usage: '动词未然形 + ないことには。表示前提不成立，后项无法实现。',
    example: '実態を把握しないことには、対策は立てられない。/ 如果不掌握实际情况，就无法制定对策。',
    examTip: '适合记成因果句型，写作也好用。'
  },
  {
    id: 'g-005',
    title: '〜に基づいて',
    level: '考研',
    meaning: '根据，基于',
    usage: '名词 + に基づいて。表示以某依据、原则、资料为基础。',
    example: 'データに基づいて判断すべきだ。/ 应该根据数据来判断。',
    examTip: '和「根拠」「調査結果」一起记忆。'
  },
  {
    id: 'g-006',
    title: '〜とされる',
    level: 'N2',
    meaning: '被认为，被视为',
    usage: '普通形 + とされる。书面表达，用于客观陈述一般看法。',
    example: '日本では協調性が重視されるとされる。/ 一般认为在日本重视协调性。',
    examTip: '阅读里常用来淡化主语，制造客观感。'
  }
];

export function getVocabularyStats() {
  const byLevel = vocabularyLevels.reduce<Record<JLPTLevel, number>>((acc, level) => {
    acc[level] = vocabularyData.filter((item) => item.level === level).length;
    return acc;
  }, {} as Record<JLPTLevel, number>);

  return {
    total: vocabularyData.length,
    byLevel
  };
}
