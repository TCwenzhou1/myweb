'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';

interface LearningProgressState {
  learnedIds: string[];
  masteredIds: string[];
  lastStudyDate: string | null;
  streak: number;
}

const STORAGE_KEY = 'japanese-learning-progress-v2';

function isSameDay(a: Date, b: Date) {
  return a.toDateString() === b.toDateString();
}

function isYesterday(lastDate: Date, current: Date) {
  const yesterday = new Date(current);
  yesterday.setDate(current.getDate() - 1);
  return isSameDay(lastDate, yesterday);
}

export function useLearningProgress(totalItems: number) {
  const [state, setState] = useState<LearningProgressState>({
    learnedIds: [],
    masteredIds: [],
    lastStudyDate: null,
    streak: 0
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;

    try {
      const parsed = JSON.parse(raw) as LearningProgressState;
      setState(parsed);
    } catch (error) {
      console.error('Failed to parse learning progress:', error);
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const markStudyToday = useCallback(() => {
    const now = new Date();
    const todayText = now.toISOString();

    setState((prev) => {
      if (prev.lastStudyDate) {
        const last = new Date(prev.lastStudyDate);
        if (isSameDay(last, now)) {
          return { ...prev, lastStudyDate: todayText };
        }

        if (isYesterday(last, now)) {
          return { ...prev, streak: prev.streak + 1, lastStudyDate: todayText };
        }
      }

      return { ...prev, streak: 1, lastStudyDate: todayText };
    });
  }, []);

  const toggleLearned = useCallback((id: string) => {
    setState((prev) => {
      const exists = prev.learnedIds.includes(id);
      const nextLearned = exists
        ? prev.learnedIds.filter((item) => item !== id)
        : [...prev.learnedIds, id];

      const nextMastered = exists
        ? prev.masteredIds.filter((item) => item !== id)
        : prev.masteredIds;

      return {
        ...prev,
        learnedIds: nextLearned,
        masteredIds: nextMastered
      };
    });

    markStudyToday();
  }, [markStudyToday]);

  const toggleMastered = useCallback((id: string) => {
    setState((prev) => {
      const mastered = prev.masteredIds.includes(id);
      const learned = prev.learnedIds.includes(id);

      const nextLearned = learned ? prev.learnedIds : [...prev.learnedIds, id];
      const nextMastered = mastered
        ? prev.masteredIds.filter((item) => item !== id)
        : [...prev.masteredIds, id];

      return {
        ...prev,
        learnedIds: nextLearned,
        masteredIds: nextMastered
      };
    });

    markStudyToday();
  }, [markStudyToday]);

  const resetProgress = useCallback(() => {
    setState({
      learnedIds: [],
      masteredIds: [],
      lastStudyDate: null,
      streak: 0
    });
  }, []);

  const stats = useMemo(() => {
    const learnedCount = state.learnedIds.length;
    const masteredCount = state.masteredIds.length;
    const progressPercent = totalItems > 0 ? Math.round((masteredCount / totalItems) * 100) : 0;

    return {
      learnedCount,
      masteredCount,
      totalItems,
      progressPercent,
      streak: state.streak
    };
  }, [state.learnedIds.length, state.masteredIds.length, state.streak, totalItems]);

  return {
    progress: state,
    stats,
    toggleLearned,
    toggleMastered,
    resetProgress
  };
}
