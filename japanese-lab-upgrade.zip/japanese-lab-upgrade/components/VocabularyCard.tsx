'use client';

import { VocabularyItem } from '@/lib/japaneseData';

interface VocabularyCardProps {
  item: VocabularyItem;
  learned: boolean;
  mastered: boolean;
  onToggleLearned: (id: string) => void;
  onToggleMastered: (id: string) => void;
}

export function VocabularyCard({
  item,
  learned,
  mastered,
  onToggleLearned,
  onToggleMastered
}: VocabularyCardProps) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-2xl font-bold text-slate-900">{item.word}</h3>
            <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
              {item.level}
            </span>
            <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">
              {item.partOfSpeech}
            </span>
          </div>

          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-600">
            <span>かな：{item.kana}</span>
            <span>罗马音：{item.romaji}</span>
          </div>

          <p className="mt-2 text-base font-medium text-slate-800">{item.meaning}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => onToggleLearned(item.id)}
            className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
              learned
                ? 'bg-blue-600 text-white'
                : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            {learned ? '已学过' : '标记已学'}
          </button>
          <button
            type="button"
            onClick={() => onToggleMastered(item.id)}
            className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
              mastered
                ? 'bg-emerald-600 text-white'
                : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            {mastered ? '已掌握' : '标记掌握'}
          </button>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <section className="rounded-xl bg-slate-50 p-4">
          <h4 className="text-sm font-semibold text-slate-900">发音</h4>
          <p className="mt-2 text-sm leading-6 text-slate-700">{item.pronunciation}</p>

          <h4 className="mt-4 text-sm font-semibold text-slate-900">核心用法</h4>
          <p className="mt-2 text-sm leading-6 text-slate-700">{item.usageCore}</p>

          <h4 className="mt-4 text-sm font-semibold text-slate-900">考试提醒</h4>
          <p className="mt-2 text-sm leading-6 text-slate-700">{item.examFocus}</p>
        </section>

        <section className="rounded-xl bg-amber-50 p-4">
          <h4 className="text-sm font-semibold text-slate-900">高频句型</h4>
          <div className="mt-2 flex flex-wrap gap-2">
            {item.usagePatterns.map((pattern) => (
              <span
                key={pattern}
                className="rounded-full bg-white px-3 py-1 text-xs font-medium text-slate-700"
              >
                {pattern}
              </span>
            ))}
          </div>

          <h4 className="mt-4 text-sm font-semibold text-slate-900">常见搭配</h4>
          <ul className="mt-2 space-y-1 text-sm leading-6 text-slate-700">
            {item.collocations.map((collocation) => (
              <li key={collocation}>• {collocation}</li>
            ))}
          </ul>
        </section>
      </div>

      <section className="mt-4 rounded-xl bg-slate-50 p-4">
        <h4 className="text-sm font-semibold text-slate-900">例句</h4>
        <div className="mt-3 space-y-4">
          {item.examples.map((example, index) => (
            <div key={`${item.id}-${index}`} className="rounded-xl bg-white p-4">
              <p className="text-sm font-medium leading-7 text-slate-900">{example.jp}</p>
              <p className="mt-1 text-sm text-slate-500">{example.kana}</p>
              <p className="mt-2 text-sm leading-6 text-slate-700">{example.zh}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-4 flex flex-wrap gap-2">
        {item.tags.map((tag) => (
          <span
            key={tag}
            className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600"
          >
            #{tag}
          </span>
        ))}
      </div>
    </article>
  );
}
