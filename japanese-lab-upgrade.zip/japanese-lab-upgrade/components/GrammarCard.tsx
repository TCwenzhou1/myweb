'use client';

import { GrammarItem } from '@/lib/japaneseData';

interface GrammarCardProps {
  item: GrammarItem;
}

export function GrammarCard({ item }: GrammarCardProps) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-xl font-bold text-slate-900">{item.title}</h3>
        <span className="rounded-full bg-violet-50 px-2.5 py-1 text-xs font-semibold text-violet-700">
          {item.level}
        </span>
      </div>
      <p className="mt-3 text-sm font-medium text-slate-800">{item.meaning}</p>
      <div className="mt-4 space-y-3 text-sm leading-6 text-slate-700">
        <div>
          <p className="font-semibold text-slate-900">接续 / 用法</p>
          <p className="mt-1">{item.usage}</p>
        </div>
        <div>
          <p className="font-semibold text-slate-900">例句</p>
          <p className="mt-1">{item.example}</p>
        </div>
        <div>
          <p className="font-semibold text-slate-900">考试提醒</p>
          <p className="mt-1">{item.examTip}</p>
        </div>
      </div>
    </article>
  );
}
