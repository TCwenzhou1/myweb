# Japanese Lab Upgrade

这是一个可直接接入 Next.js App Router 项目的源码补丁包，目标：

1. 扩展到 JLPT N1 / N2 学习
2. 增加「考研日语核心词汇」专区
3. 每个词条增加更接近 Moji 风格的字段：
   - 日文
   - 假名
   - 罗马音
   - 中文释义
   - 发音提示
   - 核心用法
   - 高频搭配
   - 高频句型
   - 考试提醒
   - 例句

## 文件说明

- `lib/japaneseData.ts`
  统一词汇与语法数据，已包含 N1 / N2 / 考研样例词条。
- `lib/useLearningProgress.ts`
  localStorage 持久化学习进度与连续学习天数。
- `components/VocabularyCard.tsx`
  Moji 风格强化版词汇卡组件。
- `components/GrammarCard.tsx`
  语法卡组件。
- `app/lab/page.tsx`
  升级后的实验室页面。

## 接入方式

把这些文件覆盖/新增到你的项目中即可。

如果你项目里原本已经有：
- `app/lab/page.tsx`
- `lib/japaneseData.ts`
- `components/VocabularyCard.tsx`
- `components/GrammarCard.tsx`
- `lib/useLearningProgress.ts`

建议先备份原文件，再合并本补丁。

## 还可以继续加的下一步

- 真正的音频朗读（TTS / mp3）
- 错题本 / 收藏夹
- Anki 式复习算法
- 词汇听写模式
- 近义词 / 反义词 / 易混词对比

## 重要说明

这个包重点补的是 **N2 / N1 / 考研核心词汇**。
如果你原项目里已经有 N5 / N4 / N3 数据，**不要直接覆盖丢掉原数组**，而是把旧数据和这里的新数据合并。
