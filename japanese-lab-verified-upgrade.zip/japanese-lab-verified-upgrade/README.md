# Japanese Lab Verified Upgrade

这是一份可直接接入 Next.js App Router 项目的补丁包，目标是把原来的日语学习页升级成：

1. **Core 2000 高频核心层**
2. **Full N2/N1 扩展层**
3. **考研精讲词层**
4. **TTS 音频播放**
5. **收藏本**
6. **SM-2 风格复习算法**

## 这版解决的核心问题

### 1) 词量不够
你原来的少量样例词，远远不足以称为“考研日语核心词库”。

这版内置：
- Core 高频核心：**2000**
- Full 全量：**4476**
- 其中考研精讲：**52**

### 2) 不再把“JLPT 词级”说成官方绝对标准
当前 JLPT 官方更强调能力和样题，不提供可直接背诵的现行官方词表。
所以这版采用的是：
- **社区成熟 JLPT 词表**
- **JMdict 体系校对思路**
- **手工补充考研重点词**

### 3) 不乱批量机翻
为了避免“2000 个词全自动汉化但没校对”带来的学习风险：
- 批量层保留 **英文 gloss**
- 精讲层补 **中文释义 + 搭配 + 考试提醒**

## 文件

- `app/lab/page.tsx`
- `components/VocabularyCard.tsx`
- `components/ReviewSession.tsx`
- `lib/vocabularyBank.ts`
- `lib/useJapaneseLabState.ts`
- `lib/useSpeechSynthesis.ts`
- `lib/srs.ts`
- `scripts/build_core_deck.py`

## 接入方式

把这些文件复制到你的项目中即可。

如果你已有同名文件，建议先备份。

## 你接下来最值得继续做的两步

### A. 真正做“精讲中文层”
现在只有高优先级考研词是手工精讲。
下一步应该把常考 300~500 词继续补成：
- 中文释义
- 常见搭配
- 近义辨析
- 高频例句

### B. 真正接上服务端 TTS
当前版本直接使用浏览器内建 TTS。
优点是部署最轻；
缺点是不同浏览器 / 不同设备上的声音质量不一致。

如果你后面想做得更像成熟 App，可以再接：
- Edge TTS
- Azure Speech
- Google Cloud TTS
- ElevenLabs（日语效果需你自己试听评估）

## 数据再生成

`scripts/build_core_deck.py` 用的是本次确认过的结构，方便你以后继续扩词。
