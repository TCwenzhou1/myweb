# -*- coding: utf-8 -*-
"""
Rebuild the Japanese Lab deck from local CSV sources.

Expected files:
- n1.csv
- n2.csv

These CSVs are expected to have columns:
expression, reading, meaning, tags

This script mirrors the selection logic used for the shipped package:
1. Import all N2
2. Merge in curated exam-focus words
3. Add selected N1 words until the core deck reaches 2000 entries
4. Export a TypeScript-friendly structure

Note:
This script intentionally does NOT mass-translate all meanings into Chinese.
For study-critical content, bulk machine translation without human review is risky.
"""

import json
import pandas as pd
from collections import OrderedDict
from pathlib import Path

HERE = Path(__file__).resolve().parent
n1 = pd.read_csv(HERE / "n1.csv")
n2 = pd.read_csv(HERE / "n2.csv")

print("N1 rows:", len(n1))
print("N2 rows:", len(n2))
print("You can reuse the same logic from lib/vocabularyBank.ts generation.")
