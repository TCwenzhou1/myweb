# Attribution

This package separates **data provenance** from **UI implementation**:

## Bulk JLPT deck layer
Used for large-scale N2/N1 coverage:
- Community JLPT word-list tradition derived from Tanos/Jonathan Waller style lists
- Meanings kept as source glosses to reduce unreviewed translation noise
- JLPT spelling/entry alignment approach informed by JMdict-oriented community work

## Manual exam-focus layer
- Hand-curated exam-oriented Chinese notes
- Added specifically for high-yield reading / argument / logic vocabulary

## Browser TTS
- Uses the browser's built-in Web Speech API / speechSynthesis entry point
- Voice quality depends on the device/browser language pack
